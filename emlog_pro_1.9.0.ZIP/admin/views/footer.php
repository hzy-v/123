<?php if (!defined('EMLOG_ROOT')) {
	exit('error!');
} ?>
</div>
</div>
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Powered by <a href="http://www.emlog.net">emlog</a> </span>
        </div>
    </div>
</footer>
</div>
</div>
<?php doAction('adm_footer') ?>
<script src="./views/js/sb-admin-2.min.js?t=<?= Option::EMLOG_VERSION_TIMESTAMP ?>"></script>
</body>
</html>
